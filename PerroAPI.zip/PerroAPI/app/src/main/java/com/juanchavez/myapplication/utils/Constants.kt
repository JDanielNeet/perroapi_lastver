package com.juanchavez.myapplication.utils

object Constants {

    //const val BASE_URL: String = "https://www.serverbpw.com/"

    //const val BASE_URL: String = "http://10.0.2.2:8888/"
    const val BASE_URL: String = "https://private-d61f1b-perros.apiary-mock.com/PerrosAPI/"

    const val LOGTAG = "LOGS"

}